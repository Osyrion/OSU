package cz.durovic;

public class RaceResult implements Comparable<RaceResult> {
    private String name;
    private String lapTime;

    public RaceResult(String name, int minutes, int seconds, int milliseconds) {
        if (name != null) {
            this.name = name;
        } else {
            throw new NullArgumentException("name");
        }

        this.lapTime = composeLapTime(minutes, seconds, milliseconds);
    }

    public String composeLapTime(int minutes, int seconds, int milliseconds) {
        String min = "";
        String sec = "";
        String msc = "";
        String ret;

        if (minutes >= 0 && minutes < 60) {
            min = "" + minutes;
        } else {
            throw new IllegalArgumentException("Number '" + minutes + "' is out of range.");
        }

        if (seconds >= 0 && seconds < 60) {
            sec = "" + seconds;
        } else {
            throw new IllegalArgumentException("Number '" + seconds + "' is out of range.");
        }

        if (milliseconds >= 0 && milliseconds < 1000) {
            msc = "" + milliseconds;
        } else {
            throw new IllegalArgumentException("Number '" + milliseconds + "' is out of range.");
        }

        if (minutes - 10 < 0) { min = "0" + min; }
        if (seconds - 10 < 0) { sec = "0" + sec; }
        if (milliseconds - 100 < 0) { msc = "0" + msc; }
        if (milliseconds - 10 < 0) { msc = "00" + msc; }

        ret = "    " + min + ":" + sec + "." + msc;

        return ret;
    }

    public String toString() {
        return this.name + " " + this.lapTime;
    }

    public int compareTo(RaceResult o) {
        return this.lapTime.compareTo(o.lapTime);
    }

    public String getLapTime() {
        return lapTime;
    }

    public String getName() {
        return name;
    }

}